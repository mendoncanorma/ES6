import {rectArea,sqrt} from './module';
var result=rectArea(2,4);
console.log(result);