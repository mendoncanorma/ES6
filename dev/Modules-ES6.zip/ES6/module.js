    export function pi(){
        return 3.14;
    }

    export function rectArea(l,b){
        return l*b;
    }
   
    export function  sqrt(number){
        return Math.sqrt(number);
    }