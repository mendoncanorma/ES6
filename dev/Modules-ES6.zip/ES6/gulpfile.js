var gulp = require("gulp");
var babel = require("gulp-babel");
var babelify = require('babelify');
var browserify = require('browserify');
var source = require('vinyl-source-stream');

gulp.task('modules', function() {
    browserify({
    entries: './application.js',
    debug: true
    })
    .transform(babelify)
    .bundle()
    .pipe(source('output.js'))
    .pipe(gulp.dest('./prod'));
});


gulp.task('select', function() {
    browserify({
    entries: './select.js',
    debug: true
    })
    .transform(babelify)
    .bundle()
    .pipe(source('moduleselect.js'))
    .pipe(gulp.dest('./prod'));
});