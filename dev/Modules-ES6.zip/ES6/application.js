import Maths from './Maths';
var x = new Maths();
var result=x.rectArea(2,4)
console.log(result);