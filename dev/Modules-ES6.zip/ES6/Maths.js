class Maths{
    
   rectArea(l,b) {
        return l*b;
    } 
}

module.exports = Maths;