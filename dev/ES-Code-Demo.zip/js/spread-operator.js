var number = [1,2,3,4,5];

max = Math.max(...number);
console.log(max);


function logMessages(message,...args)
{
    console.log(message,...args);
}
console.log("SkillBakery Studio Presents %s : %s","Master JavaScript & jQuery","Learn JavaScript & jQuery");
