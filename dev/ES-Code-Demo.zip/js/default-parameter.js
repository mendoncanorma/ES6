  function assignCourseES5(courseName, publishedBy)
  {
      courseName=courseName || "Master Javascript & jQuery";
      publishedBy=publishedBy || "SkillBakery";

      console.log(courseName);
  }


  function assignCourseES6( courseName="Master Javascript & jQuery", publishedBy="SkillBakery"){
      console.log(courseName+" "+publishedBy);
      
  }

  assignCourseES6();
  assignCourseES6("Master ReactJS");
  assignCourseES6("Master ReactJS","SkillBakery.com");