"use strict";
function* logMessages(){
    console.log("Learning ES6");

    let sb=yield "SkillBakery";

    sb=yield sb + " ES6";

    yield sb + "Udemy";
}

let msg=logMessages();
/*
for(let word of msg) 
console.log(word);
*/

console.log(msg);
let output=msg.next("ES6 is exciting").value;
console.log(output);

let result=msg.next("ES6 is cool").value;
console.log(result);

let final_result=msg.next("ES6 is awesome").value;
console.log(final_result);

