 var [d, m, y] = [15, 07, 2015];

 //var d=15,m=07,y=2015;

 //console.log(m);
 //[m,y] = [y,m];

 //console.log(y);
 //console.log(m);

 //function getDate(){ return [15,07,2015];}
 //var [d,m]=getDate();
 //var [,,y]=getDate();

 //console.log(d);
 //console.log(m);
 //console.log(y);

function currentDate() { return { d:15, m:07, y:2015 }; }
//var { m:month, y:year } = currentDate(); 


var {m,y}=currentDate();
console.log(m);
console.log(y);