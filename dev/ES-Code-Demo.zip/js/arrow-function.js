/*
var helloWorld=function(name,greeting) {
  return name +" "+ greeting;
}
console.log(helloWorld("SkillBakery", "Start Learning Today!"));

var newGreeting = (name,greeting) => {
      return name +" "+ greeting;
}

console.log(newGreeting("SkillBakery!", "Start Learning Today!"));

var greeting = (name,greeting) =>  name +" "+ greeting;

console.log(newGreeting("SkillBakery!!", "Start Learning Today!"));

var greetingDefault = greeting =>  greeting;
console.log(greetingDefault("Start Learning Today!"));

var greetingNoParam = () =>  "Hello SkillBakery";
console.log(greetingNoParam());

var courses = ["Master JavaScript and jQuery",
"Master KnockoutJS", "Master AngularJS", "Master ReactJS", "Master EmberJs",
"Master BackboneJS", "Advanced jQuery Tips and Tricks", "Amazon Web Services",
"Browser Developer Tools"];

console.log(
    courses.map(course => {
        return course.toUpperCase();
    })
);

var numberArr = [2,4,6,12,10,78];
var sortedArr=numberArr.sort( (a, b)=> a > b? 1: -1 );

console.log(sortedArr);
*/
function Course(){

    this.name = "Master ES6";
    this.description = "The Next Level";
    this.author = "SkillBakery";
    this.getSummary = function () {
        return this.name + ", " + this.description;
    };

    this.getDetails = function() {
       window.setTimeout( ()=> { 
                console.log( this.getSummary() + " "+ this.author );
                }, 1000 );
    }

}

var course=new Course();
course.getDetails();