function restParametersES6(firstName, lastName, ...details){  
    
    console.log(firstName+" "+lastName)
    console.log(details);
    for(contact in details)
    {
        console.log(details[contact]);
    }
}

restParametersES6("SkillBakery","Studio",
                  "http://skillbakery.com","http://udemy.com/u/skillbakery");