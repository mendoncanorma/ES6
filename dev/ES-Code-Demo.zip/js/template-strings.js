var name = 'SkillBakery', tag = "Start \`Learning Today";
var s = `${name}, tag line is ${tag}`


var lengthString=`lorel ipsum
sample String
Demo`;

console.log(s);
console.log(lengthString);