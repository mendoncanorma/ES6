define(function (require) {
    var namedModule = require('Mathe');
});