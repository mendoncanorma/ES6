/*
$.ajax("http://services.odata.org/V4/Northwind/Northwind.svc/",{
    success: function(data){
        console.log(data.value);
    },
    error:function(){
        console.log("failed to fetch data");
    }
});
*/


//Now with ES6 Promises

fetch("http://services.odata.org/V4/Northwind/Northwind.svc/", {
	method: 'get'
}).then(function(response){
   return response.json();
}).then(function(data){
    console.log(data.value);
}).catch(function(){
     console.log("failed to fetch data");
});
