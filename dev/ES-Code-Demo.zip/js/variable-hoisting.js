
/*
x = 6; // Assign 6 to x

elem = document.getElementById("divContainer"); // Find an element 
elem.innerHTML = x; // Display x in the element

var x; // Declare x
*/
/*
var x; // Declare x
x = 6; // Assign 6 to x

elem = document.getElementById("divContainer"); // Find an element 
elem.innerHTML = x;  // Display x in the element
*/
/*
var x = 5; // Initialize x
var y = 7; // Initialize y

elem = document.getElementById("divContainer"); // Find an element 
elem.innerHTML = x + " " + y;           // Display x and y

*/
/*
var x = 5; // Initialize x

elem = document.getElementById("divContainer"); // Find an element 
elem.innerHTML = x + " " + y;           // Display x and y

var y = 7; // Initialize y
*/

var x = 5; // Initialize x
var y;     // Declare y

elem = document.getElementById("divContainer"); // Find an element 
elem.innerHTML = x + " " + y;           // Display x and y

y = 7;    // Assign 7 to y