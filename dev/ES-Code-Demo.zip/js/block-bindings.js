 "use strict";
 function blockBindingDemo(){
     
    let roll_num = 123;
    var rol=123;
    if(true){
        let roll_num = 456;  
        var rol=789;   // Here roll_num is treated as a different number
        console.log(roll_num);  // 456
        console.log(rol); 
    }
    console.log(roll_num);    // 123
    console.log(rol); 
}

blockBindingDemo();

var i=0;

for(let i=0; i<5; i++){
    console.log(i);   // 0 1 2 3 4 
}
console.log(i);// 0