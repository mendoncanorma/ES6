"use strict";
var course = {
              name:"Master JavaScript & jQuery",
	          publisher:"SkillBakery"
             };


function courseDetails(c){
 let {name,publisher} = c;
 console.log(name+" "+publisher);
}

courseDetails(course);