
//constructor
/*
var promise = new Promise(function(resolve,reject){

        if(success){
            resolve(data);
        }
       else{
            reject("Error");
        }
    });
*/
var promise = new Promise(function(resolve,reject){

  $.ajax("http://services.odata.org/V4/Northwind/Northwind.svc/",{
        success: function(data){
            resolve(data);
        },
        error:function(){
            reject("Error");
        }
    });

});

promise.then(function(result){
  console.log(result);
},function(err) {
  console.log(err);
});

//Promise.all([promise])
//Promise.race([promise])
//Promise.reject(reason)
//Promise.resolve(value)
/*
Promise.all([promise,obj]).then(function(results){
//results[0];
//results[1];

},function(){

});
*/