"use strict";
var words = ['Skill', 'Bakery', 'Studio'];
//entries
for(let word of words.entries()) 
console.log(word);
//values
for(let word of words.values()) 
console.log(word);

for(let word of words.keys()) 
console.log(word);